package com.example.surabhi.button;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
   Button red,green,blue;
   EditText text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        red=(Button) findViewById(R.id.red);
        green=(Button) findViewById(R.id.green);
        blue=(Button) findViewById(R.id.blue);
        text=(EditText) findViewById(R.id.text);
        text.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String a[]=s.toString().split(",");
                int i=a.length;
                for(int j=0;j<i;j++) {

                    if (a[j].trim().equals("red")) {

                        red.setBackgroundColor(Color.rgb(255, 0, 0));

                    } else if (a[j].equals("blue")) {
                        blue.setBackgroundColor(Color.rgb(0, 0, 255));

                    } else if (a[j].equals("green")) {

                        green.setBackgroundColor(Color.rgb(0, 255, 0));
                    } else {
                        red.setBackgroundColor(Color.rgb(255, 255, 255));
                        blue.setBackgroundColor(Color.rgb(255, 255, 255));
                        green.setBackgroundColor(Color.rgb(255, 255, 255));
                    }

                }

            }
        });
    }
}
